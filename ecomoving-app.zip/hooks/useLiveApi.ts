import { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { createPcmBlob, calculateRMS, decodeAudioData, decodeBase64 } from '../utils/audioUtils';

const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

export interface UseLiveApiParams {
  onToolCall?: (toolCalls: any[]) => Promise<any[]>;
  systemInstruction?: string;
  tools?: any[];
}

export interface UseLiveApiReturn {
  isConnected: boolean;
  isConnecting: boolean;
  volume: number;
  connect: () => Promise<void>;
  disconnect: () => void;
  error: Error | null;
}

export function useLiveApi({ onToolCall, systemInstruction, tools }: UseLiveApiParams = {}): UseLiveApiReturn {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [volume, setVolume] = useState(0);
  const [error, setError] = useState<Error | null>(null);

  const sessionRef = useRef<any>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const outputSourceRef = useRef<AudioBufferSourceNode | null>(null);
  
  // Track audio scheduling
  const nextStartTimeRef = useRef<number>(0);

  const disconnect = useCallback(() => {
    if (sessionRef.current) {
      // There is no explicit close() method on the session object in the SDK types in some versions,
      // but we can nullify it and stop streams. 
      // If the SDK supports close(), call it. Otherwise rely on cleanup.
      // sessionRef.current.close?.(); 
      sessionRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    if (inputProcessorRef.current) {
      inputProcessorRef.current.disconnect();
      inputProcessorRef.current = null;
    }

    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    setIsConnected(false);
    setIsConnecting(false);
    setVolume(0);
    nextStartTimeRef.current = 0;
  }, []);

  const connect = useCallback(async () => {
    if (isConnected || isConnecting) return;

    try {
      setIsConnecting(true);
      setError(null);

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // 1. Setup Audio Contexts
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = audioCtx;
      nextStartTimeRef.current = audioCtx.currentTime;

      // 2. Get Microphone Stream
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      // 3. Connect to Gemini Live
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          systemInstruction: systemInstruction,
          tools: tools,
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
        callbacks: {
          onopen: () => {
            console.log('Gemini Live Session Opened');
            setIsConnected(true);
            setIsConnecting(false);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio Output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              try {
                const audioData = decodeBase64(base64Audio);
                const buffer = await decodeAudioData(audioData, audioCtx, 24000, 1);
                
                // Schedule playback
                const source = audioCtx.createBufferSource();
                source.buffer = buffer;
                source.connect(audioCtx.destination);
                
                // Ensure smooth playback queue
                const now = audioCtx.currentTime;
                // If next start time is in the past, reset to now
                const startTime = Math.max(nextStartTimeRef.current, now);
                source.start(startTime);
                
                nextStartTimeRef.current = startTime + buffer.duration;
                outputSourceRef.current = source;
              } catch (e) {
                console.error('Error decoding audio:', e);
              }
            }

            // Handle Tool Calls
            if (message.toolCall && onToolCall) {
              try {
                const responses = await onToolCall(message.toolCall.functionCalls);
                // Send tool response back
                sessionPromise.then(session => {
                  session.sendToolResponse({
                    functionResponses: responses
                  });
                });
              } catch (e) {
                console.error('Error executing tool:', e);
              }
            }
            
            // Handle Interruption (stop current playback)
            if (message.serverContent?.interrupted) {
               // Note: We can't easily stop specific scheduled nodes in this simple implementation
               // without tracking them all. For now, we just reset the time cursor.
               // In a robust app, we would track and stop active sources.
               nextStartTimeRef.current = audioCtx.currentTime;
            }
          },
          onclose: () => {
            console.log('Session closed');
            disconnect();
          },
          onerror: (e) => {
            console.error('Session error:', e);
            setError(new Error("Connection error"));
            disconnect();
          }
        }
      });

      // 4. Setup Input Processing (Mic -> Gemini)
      // Use a separate context for input at 16kHz if possible, or resample.
      // For simplicity, we use the same context but we'll downsample in createPcmBlob if needed or just send as is.
      // The createPcmBlob utility handles conversion to 16kHz PCM.
      
      const inputSource = audioCtx.createMediaStreamSource(stream);
      const processor = audioCtx.createScriptProcessor(4096, 1, 1);
      inputProcessorRef.current = processor;

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        
        // Update volume visualization
        const rms = calculateRMS(inputData);
        setVolume(prev => prev * 0.8 + rms * 0.2); // Smooth

        // Send to Gemini
        const pcmBlob = createPcmBlob(inputData);
        sessionPromise.then(session => {
           session.sendRealtimeInput({ media: pcmBlob });
        });
      };

      inputSource.connect(processor);
      processor.connect(audioCtx.destination); // Required for script processor to run, but volume 0?
      // Actually, better to connect to a mute gain node to avoid feedback loop if we are just recording.
      // But ScriptProcessor needs a destination.
      // To avoid hearing yourself:
      const muteNode = audioCtx.createGain();
      muteNode.gain.value = 0;
      processor.disconnect(); // clear previous
      processor.connect(muteNode);
      muteNode.connect(audioCtx.destination);

      sessionRef.current = await sessionPromise;

    } catch (err: any) {
      console.error("Failed to connect:", err);
      setError(err);
      setIsConnecting(false);
      disconnect();
    }
  }, [disconnect, isConnected, isConnecting, onToolCall, systemInstruction, tools]);

  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    isConnected,
    isConnecting,
    volume,
    connect,
    disconnect,
    error
  };
}